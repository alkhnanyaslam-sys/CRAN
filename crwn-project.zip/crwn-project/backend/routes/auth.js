// routes/auth.js
// Handles admin login (PIN check) and changing the PIN.

const express = require('express');
const crypto = require('crypto');
const { readData, writeData } = require('../utils/db');
const adminAuth = require('../middleware/adminAuth');

const router = express.Router();

// POST /api/auth/login  { pin }
router.post('/login', (req, res) => {
  const { pin } = req.body;
  const settings = readData('settings') || { pin: '2580' };

  if (!pin || pin !== settings.pin) {
    return res.status(401).json({ error: 'الرقم السري غلط' });
  }

  const token = crypto.randomBytes(24).toString('hex');
  settings.activeToken = token;
  writeData('settings', settings);

  res.json({ token });
});

// POST /api/auth/logout
router.post('/logout', adminAuth, (req, res) => {
  const settings = readData('settings') || {};
  delete settings.activeToken;
  writeData('settings', settings);
  res.json({ ok: true });
});

// POST /api/auth/change-pin  { newPin }   (requires admin token)
router.post('/change-pin', adminAuth, (req, res) => {
  const { newPin } = req.body;
  if (!newPin || newPin.length < 4) {
    return res.status(400).json({ error: 'الرقم السري لازم يكون 4 أرقام على الأقل' });
  }
  const settings = readData('settings') || {};
  settings.pin = newPin;
  writeData('settings', settings);
  res.json({ ok: true });
});

module.exports = router;
